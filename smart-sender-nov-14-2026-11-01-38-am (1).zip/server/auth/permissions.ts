import { normalizePhoneDigits, normalizePhoneE164 } from '../config/env.ts';
import { getSetting } from '../database/repositories/settingsRepo.ts';
import {
  getWhatsAppUserByPhone,
  type ContactPermission,
  type WhatsAppRole,
} from '../database/repositories/usersRepo.ts';

export interface PermissionCheckResult {
  allowed: boolean;
  role: WhatsAppRole;
  permission: ContactPermission;
  phoneDigits: string;
  phoneE164: string;
  displayName: string;
  nickname: string;
  reason?: string;
}

/**
 * Verifies sender identity strictly by real WhatsApp phone number,
 * ensuring user exists in authorized_users, is_active = 1, and permission != 'blocked'.
 */
export function checkWhatsAppPermission(
  rawSenderPhone: string,
  requiredMinimumRole: 'authorized' | 'admin' | 'owner' = 'authorized'
): PermissionCheckResult {
  const phoneDigits = normalizePhoneDigits(rawSenderPhone);
  const phoneE164 = normalizePhoneE164(rawSenderPhone);
  if (!phoneDigits || !phoneE164) {
    return {
      allowed: false,
      role: 'unauthorized',
      permission: 'blocked',
      phoneDigits: '',
      phoneE164: '',
      displayName: '',
      nickname: '',
      reason: 'تعذر التحقق من رقم المرسل.',
    };
  }

  const configuredOwnerDigits = normalizePhoneDigits(getSetting('owner_phone', ''));
  if (configuredOwnerDigits && phoneDigits === configuredOwnerDigits) {
    const ownerRecord = getWhatsAppUserByPhone(phoneDigits);
    const nick = ownerRecord?.nickname || ownerRecord?.display_name || 'مالك النظام';
    return {
      allowed: true,
      role: 'owner',
      permission: 'chat',
      phoneDigits,
      phoneE164,
      displayName: nick,
      nickname: nick,
    };
  }

  const record = getWhatsAppUserByPhone(phoneDigits);
  if (
    !record ||
    record.is_active === 0 ||
    record.permission === 'blocked' ||
    record.role === 'unauthorized'
  ) {
    return {
      allowed: false,
      role: 'unauthorized',
      permission: 'blocked',
      phoneDigits,
      phoneE164,
      displayName: record?.display_name || phoneE164,
      nickname: record?.nickname || record?.alias || phoneDigits,
      reason: 'غير مصرح لك بالتحكم في البوت أو الدردشة.',
    };
  }

  const rank: Record<WhatsAppRole, number> = {
    unauthorized: 0,
    authorized: 1,
    admin: 2,
    owner: 3,
  };

  const hasAccess = rank[record.role] >= rank[requiredMinimumRole];
  const nick = record.nickname || record.alias || record.display_name || phoneDigits;
  return {
    allowed: hasAccess,
    role: record.role,
    permission: record.permission || 'chat',
    phoneDigits,
    phoneE164,
    displayName: record.display_name || nick,
    nickname: nick,
    reason: hasAccess ? undefined : 'صلاحياتك الحالية لا تسمح بتنفيذ هذا الإجراء.',
  };
}
