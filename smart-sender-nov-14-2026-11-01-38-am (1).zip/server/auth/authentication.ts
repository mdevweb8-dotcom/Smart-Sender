import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';
import { config } from '../config/env.ts';
import {
  findDashboardUserById,
  findDashboardUserByUsername,
  recordDashboardLogin,
  type DashboardRole,
  type DashboardUser,
} from '../database/repositories/usersRepo.ts';
import { logSystem } from '../database/repositories/logsRepo.ts';

export interface AuthTokenPayload {
  sub: string;
  username: string;
  role: DashboardRole;
}

export interface AuthenticatedRequest extends Request {
  user?: DashboardUser;
}

export function signAuthToken(user: DashboardUser): string {
  const payload: AuthTokenPayload = {
    sub: user.id,
    username: user.username,
    role: user.role,
  };
  return jwt.sign(payload, config.jwtSecret, { expiresIn: '7d' });
}

export function verifyAuthToken(token: string): AuthTokenPayload | null {
  try {
    return jwt.verify(token, config.jwtSecret) as AuthTokenPayload;
  } catch {
    return null;
  }
}

export function authenticateDashboardCredentials(
  username: string,
  password: string
): { ok: true; token: string; user: DashboardUser } | { ok: false; error: string } {
  const cleanUser = (username || '').trim();
  if (!cleanUser || !password) {
    return { ok: false, error: 'اسم المستخدم وكلمة المرور مطلوبان' };
  }

  const userRecord = findDashboardUserByUsername(cleanUser);
  if (!userRecord || userRecord.is_active === 0) {
    logSystem('warn', 'auth', 'فشل تسجيل الدخول: مستخدم غير موجود أو معطل', { username: cleanUser });
    return { ok: false, error: 'بيانات الدخول غير صحيحة' };
  }

  const valid = bcrypt.compareSync(password, userRecord.password_hash);
  if (!valid) {
    logSystem('warn', 'auth', 'فشل تسجيل الدخول: كلمة مرور غير صحيحة', { username: cleanUser });
    return { ok: false, error: 'بيانات الدخول غير صحيحة' };
  }

  recordDashboardLogin(userRecord.id);
  const safeUser: DashboardUser = {
    id: userRecord.id,
    username: userRecord.username,
    role: userRecord.role,
    full_name: userRecord.full_name,
    is_active: userRecord.is_active,
    created_at: userRecord.created_at,
    last_login_at: new Date().toISOString(),
  };

  const token = signAuthToken(safeUser);
  logSystem('info', 'auth', 'تم تسجيل دخول لوحة التحكم بنجاح', { username: safeUser.username, role: safeUser.role });
  return { ok: true, token, user: safeUser };
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization || '';
  let token = '';
  if (authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else if (typeof req.query.token === 'string' && req.query.token) {
    // Supported strictly for authenticated file download links
    token = req.query.token;
  }

  if (!token) {
    res.status(401).json({ error: 'مطلوب تسجيل الدخول أولاً' });
    return;
  }

  const payload = verifyAuthToken(token);
  if (!payload) {
    res.status(401).json({ error: 'جلسة الدخول غير صالحة أو منتهية' });
    return;
  }

  const user = findDashboardUserById(payload.sub);
  if (!user || user.is_active === 0) {
    res.status(401).json({ error: 'الحساب غير نشط' });
    return;
  }

  req.user = user;
  next();
}

export function requireRole(allowedRoles: DashboardRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      res.status(403).json({ error: 'ليست لديك الصلاحية الكافية لتنفيذ هذا الإجراء' });
      return;
    }
    next();
  };
}
